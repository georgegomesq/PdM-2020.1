package com.example.vaievolta

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout

class SobreActivity : AppCompatActivity() {
    private lateinit var llSobre: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sobre)

        this.llSobre = findViewById(R.id.llSobre)
        this.llSobre.setOnClickListener({
            finish()
        })
    }
}
